# Lakbay App — UI kit

High-fidelity recreation of the Lakbay commuter flow. Platform-neutral, mobile-first (412 px design width).

## Screens
- **Home.jsx** — Locked origin (current location) + destination entry, saved-place chips, recents. Built on `Input` + `Button`.
- **Results.jsx** — Ranked route list. `exactRoutes` match the destination; `similarRoutes` share the **same origin** but end at a *nearby* place, shown under a "No exact match nearby?" divider — this is the fallback behavior. Built on `RouteCard`.
- **RouteDetail.jsx** — Trip breakdown (leg timeline), aggregated crowd/reliability/walk signals, and the full `ReviewCard` list, with Write-a-review / Start-trip actions.

## Interactive demo
`index.html` is a self-contained click-through (Home → Results → Detail) using the same tokens and lucide-react icons, wrapped in a phone frame. It inlines lightweight copies of the primitives so it runs with no build step; the `.jsx` files above are the developer-handoff versions that import the real design-system components.

## Notes
- Map areas are striped placeholders labelled "map placeholder" — drop in a real map SDK (the palette expects muted teal/green route lines on a light basemap).
- Fares shown in ₱ (PHP), reflecting the Philippine commuter context; swap the currency glyph for other markets.
