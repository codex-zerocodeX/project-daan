import React from "react";
import { RouteCard } from "../../components/transit/RouteCard.jsx";

/**
 * Results — ranked route list. `exactRoutes` match the destination; `similarRoutes`
 * share the same origin but end at a *nearby* place (the fallback behavior).
 */
export function Results({ destination, exactRoutes = [], similarRoutes = [], onOpen }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-3)", padding: "var(--space-4)", background: "var(--bg-app)", fontFamily: "var(--font-sans)" }}>
      <div style={{ fontSize: "var(--text-xs)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "var(--tracking-wide)", color: "var(--text-muted)" }}>
        {exactRoutes.length} routes to {destination}
      </div>
      {exactRoutes.map((r) => <RouteCard key={r.id} {...r} onClick={() => onOpen && onOpen(r)} />)}

      {similarRoutes.length > 0 && (
        <>
          <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "6px 0" }}>
            <div style={{ flex: 1, height: 1, background: "var(--border-subtle)" }} />
            <span style={{ fontSize: "var(--text-sm)", fontWeight: 600, color: "var(--text-muted)" }}>No exact match nearby?</span>
            <div style={{ flex: 1, height: 1, background: "var(--border-subtle)" }} />
          </div>
          <div style={{ background: "var(--surface-primary-soft)", borderRadius: "var(--radius-md)", padding: "10px 14px", fontSize: "var(--text-sm)", color: "var(--primary-700)", fontWeight: 500, lineHeight: 1.4 }}>
            Same start, nearby drop-offs. These reviews come from routes ending close to your destination.
          </div>
          {similarRoutes.map((r) => <RouteCard key={r.id} {...r} similar onClick={() => onOpen && onOpen(r)} />)}
        </>
      )}
    </div>
  );
}
