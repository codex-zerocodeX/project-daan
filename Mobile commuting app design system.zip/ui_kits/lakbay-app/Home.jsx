import React, { useState } from "react";
import { Input } from "../../components/core/Input.jsx";
import { Button } from "../../components/core/Button.jsx";

/** Home — origin (locked to current location) + destination entry, favorites, recents. */
export function Home({ origin = "Ateneo, Katipunan", onSearch, favorites = ["Home", "Work", "Gateway Mall"], recents = ["Ortigas Center", "BGC Bus Stop"] }) {
  const [dest, setDest] = useState("");
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-4)", padding: "var(--space-4)", background: "var(--bg-app)", fontFamily: "var(--font-sans)" }}>
      <div>
        <div style={{ fontSize: "var(--text-sm)", color: "var(--text-muted)", fontWeight: 600 }}>Good morning</div>
        <div style={{ fontSize: "var(--text-h2)", fontWeight: 800, letterSpacing: "var(--tracking-tight)" }}>Where to today?</div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10, padding: 14, background: "var(--surface-card)", borderRadius: "var(--radius-xl)", boxShadow: "var(--shadow-lifted)", border: "1px solid var(--border-subtle)" }}>
        <Input value={origin} readOnly />
        <Input value={dest} onChange={(e) => setDest(e.target.value)} placeholder="Where to?" />
        <Button variant="primary" size="lg" fullWidth onClick={() => onSearch && onSearch(dest)}>Find routes</Button>
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {favorites.map((f) => (
          <Button key={f} variant="outline" size="sm" onClick={() => onSearch && onSearch(f)}>{f}</Button>
        ))}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {recents.map((r) => (
          <div key={r} style={{ padding: "10px 4px", fontSize: "var(--text-body-md)", color: "var(--text-body)", fontWeight: 500 }}>{r}</div>
        ))}
      </div>
    </div>
  );
}
