import React from "react";
import { ReviewCard } from "../../components/transit/ReviewCard.jsx";
import { CrowdMeter } from "../../components/transit/CrowdMeter.jsx";
import { Button } from "../../components/core/Button.jsx";

/** RouteDetail — trip breakdown + aggregated signals + the full review list. */
export function RouteDetail({ destination, route = {}, steps = [], reviews = [] }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-4)", padding: "var(--space-4)", background: "var(--bg-app)", fontFamily: "var(--font-sans)" }}>
      <div style={{ background: "var(--surface-card)", borderRadius: "var(--radius-xl)", boxShadow: "var(--shadow-lifted)", border: "1px solid var(--border-subtle)", padding: 18, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontSize: "var(--text-xs)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "var(--tracking-wide)", color: "var(--text-muted)" }}>To {destination}</div>
          <CrowdMeter level={route.crowdLevel || 2} />
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontFamily: "var(--font-mono)", fontWeight: 500, fontSize: 28, color: "var(--text-strong)" }}>{route.duration}</div>
          <div style={{ fontFamily: "var(--font-mono)", color: "var(--text-muted)" }}>{route.fare}</div>
        </div>
      </div>

      <div style={{ background: "var(--surface-card)", borderRadius: "var(--radius-lg)", border: "1px solid var(--border-subtle)", padding: 18 }}>
        <div style={{ fontSize: "var(--text-h3)", fontWeight: 700, marginBottom: 12 }}>Your trip</div>
        {steps.map((s, i) => (
          <div key={i} style={{ display: "flex", gap: 12, paddingBottom: i < steps.length - 1 ? 14 : 0 }}>
            <div style={{ fontSize: "var(--text-body-md)", fontWeight: 600, color: "var(--text-strong)", minWidth: 0 }}>
              {s.title}<div style={{ fontSize: "var(--text-sm)", color: "var(--text-muted)", fontWeight: 400 }}>{s.subtitle}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ fontSize: "var(--text-h2)", fontWeight: 700 }}>Rider reviews</div>
      {reviews.map((rev, i) => <ReviewCard key={i} {...rev} />)}

      <div style={{ display: "flex", gap: 10 }}>
        <Button variant="outline">Write a review</Button>
        <Button variant="primary" fullWidth>Start trip</Button>
      </div>
    </div>
  );
}
