---
name: alitaptap-design
description: Use this skill to generate well-branded interfaces and assets for Alitaptap (a.k.a. Daan), a firefly-themed walkability evidence guide for Metro Manila — origin→destination routing with a Daan Score, per-place community reviews, and evidence coverage. For production or throwaway prototypes/mocks. Contains design guidelines, colors, type, fonts, firefly assets, and UI-kit components.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out (especially the firefly mark/hero) and create static HTML files for the user to view. If working on production code, copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
