import * as React from "react";

export interface InfoBannerProps {
  icon?: React.ReactNode;
  children?: React.ReactNode;
  /** @default "notice" */
  tone?: "notice" | "neutral";
  style?: React.CSSProperties;
}

/** Full-width disclosure strip under the header (data caveats, fixtures, freshness). */
export function InfoBanner(props: InfoBannerProps): JSX.Element;
