Compact two/three-option segmented control; the active segment fills navy.

```jsx
<SegmentedToggle options={["6 AM","2 PM"]} value={when} onChange={setWhen} />
```
