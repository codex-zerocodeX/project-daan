import React from "react";

/**
 * Alitaptap RouteChoiceCard — one selectable routing profile
 * (e.g. Shortest time, Comfort balance). Selected fills navy.
 */
export function RouteChoiceCard({
  icon = null,
  title,
  score,
  distance,
  duration,
  places,
  selected = false,
  onClick,
  style = {},
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        flex: 1, textAlign: "left", cursor: "pointer",
        display: "flex", flexDirection: "column", gap: 8,
        padding: "12px 14px", borderRadius: "var(--radius-sm)",
        background: selected ? "var(--navy-900)" : "var(--surface-raised)",
        border: `1px solid ${selected ? "var(--navy-900)" : "var(--border-subtle)"}`,
        boxShadow: selected ? "var(--shadow-sm)" : "none",
        fontFamily: "var(--font-sans)",
        transition: "background var(--dur-fast) var(--ease-standard)",
        ...style,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 7, fontWeight: 700, fontSize: "var(--text-body-md)", color: selected ? "var(--text-on-navy)" : "var(--text-strong)" }}>
          {icon}{title}
        </span>
        {score != null && (
          <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: selected ? "var(--text-on-navy-dim)" : "var(--text-muted)" }}>{score}/100</span>
        )}
      </div>
      <div style={{ display: "flex", gap: 10, fontSize: "var(--text-sm)", color: selected ? "var(--text-on-navy-dim)" : "var(--text-muted)" }}>
        {distance && <span>{distance}</span>}
        {duration && <span>· {duration}</span>}
        {places && <span>· {places}</span>}
      </div>
    </button>
  );
}
