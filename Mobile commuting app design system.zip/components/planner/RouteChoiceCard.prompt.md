A selectable routing profile; the chosen one fills navy. Sit two in a row under a "Route choice" label.

```jsx
<RouteChoiceCard title="Shortest time" score={29} distance="1.1 km" duration="15 min" places="4 place" selected />
<RouteChoiceCard title="Comfort balance" score={40} distance="1.3 km" duration="19 min" places="6 place" />
```
