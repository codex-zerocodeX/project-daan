Shows how much of a route is backed by structural evidence; the unknown remainder is displayed, never hidden.

```jsx
<EvidenceCoverageBar coverage={75} />
```
