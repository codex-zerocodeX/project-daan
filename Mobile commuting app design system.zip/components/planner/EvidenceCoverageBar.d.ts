import * as React from "react";

export interface EvidenceCoverageBarProps {
  /** Percent of the route backed by structural evidence, 0–100. @default 75 */
  coverage?: number;
  style?: React.CSSProperties;
}

/**
 * Split bar: known evidence (calm→gold gradient) vs neutral "unknown" remainder.
 * Unknown is never hidden — it is shown, not scored.
 * @startingPoint section="Planner" subtitle="Evidence coverage bar" viewport="700x120"
 */
export function EvidenceCoverageBar(props: EvidenceCoverageBarProps): JSX.Element;
