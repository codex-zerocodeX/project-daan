import * as React from "react";

export interface SegmentedOption { value: string; label: string; }

export interface SegmentedToggleProps {
  /** String[] or {value,label}[] */
  options?: (string | SegmentedOption)[];
  value?: string;
  onChange?: (value: string) => void;
  style?: React.CSSProperties;
}

/** Compact segmented control; active segment fills navy. Used for departure time (6 AM / 2 PM). */
export function SegmentedToggle(props: SegmentedToggleProps): JSX.Element;
