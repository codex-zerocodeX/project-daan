import * as React from "react";

export interface WeatherChipProps {
  icon?: React.ReactNode;
  label?: string;
  /** @default "neutral" */
  tone?: "neutral" | "heat" | "rain" | "plain";
  style?: React.CSSProperties;
}

/** Small environmental-factor chip shown under the Daan score (feels-like, rain, weather multiplier). */
export function WeatherChip(props: WeatherChipProps): JSX.Element;
