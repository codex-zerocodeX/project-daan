import React from "react";

/** Alitaptap SegmentedToggle — small segmented control (e.g. Leave at 6 AM / 2 PM). */
export function SegmentedToggle({ options = [], value, onChange, style = {} }) {
  return (
    <div style={{ display: "inline-flex", gap: 4, padding: 3, background: "var(--surface-sunken)", borderRadius: "var(--radius-sm)", ...style }}>
      {options.map((opt) => {
        const val = typeof opt === "string" ? opt : opt.value;
        const label = typeof opt === "string" ? opt : opt.label;
        const active = val === value;
        return (
          <button
            key={val}
            type="button"
            onClick={() => onChange && onChange(val)}
            style={{
              border: "none", cursor: "pointer",
              padding: "6px 14px", borderRadius: "var(--radius-xs)",
              fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", fontWeight: 600,
              background: active ? "var(--navy-900)" : "transparent",
              color: active ? "var(--text-on-navy)" : "var(--text-muted)",
              transition: "background var(--dur-fast) var(--ease-standard)",
            }}
          >
            {label}
          </button>
        );
      })}
    </div>
  );
}
