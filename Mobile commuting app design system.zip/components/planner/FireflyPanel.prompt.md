The signature dark firefly panel — glowing mark and light trail on navy — used for empty/prompt states like "Select a place on the map".

```jsx
<FireflyPanel image="../../assets/firefly-hero.png"
  title="Select a place on the map"
  subtitle="See reviews compiled for that place and route questions that mention it." />
```

Set `image` to the firefly-hero.png path relative to the page you render on.
