import React from "react";

/**
 * Alitaptap FireflyPanel — the dark "night" call-to-action panel.
 * Firefly mark glows at left with a trailing light path. Used for the
 * empty map-context state ("Select a place on the map").
 */
export function FireflyPanel({
  title = "Select a place on the map",
  subtitle = "See reviews compiled for that place and route questions that mention it.",
  image = "assets/firefly-hero.png",
  height = 92,
  style = {},
}) {
  return (
    <div style={{
      position: "relative", overflow: "hidden",
      minHeight: height, borderRadius: "var(--radius-lg)",
      background: "var(--surface-night)",
      backgroundImage: `linear-gradient(90deg, oklch(0.205 0.035 258) 34%, oklch(0.205 0.035 258 / 0) 78%), url(${image})`,
      backgroundSize: "auto 220%, cover", backgroundPosition: "left center, right center",
      backgroundRepeat: "no-repeat",
      display: "flex", alignItems: "center", gap: 16,
      padding: "16px 20px 16px 78px",
      fontFamily: "var(--font-sans)", ...style,
    }}>
      <div>
        <div style={{ fontFamily: "var(--font-serif)", fontWeight: 600, fontSize: "var(--text-h3)", color: "var(--text-on-navy)" }}>{title}</div>
        <div style={{ fontSize: "var(--text-sm)", color: "var(--text-on-navy-dim)", marginTop: 3, maxWidth: 520, lineHeight: 1.4 }}>{subtitle}</div>
      </div>
    </div>
  );
}
