import React from "react";

/** Alitaptap WeatherChip — a small factor chip (feels-like temp, rain %, multiplier). */
export function WeatherChip({ icon = null, label, tone = "neutral", style = {} }) {
  const tones = {
    neutral: { bg: "var(--surface-sunken)", fg: "var(--text-body)", ic: "var(--icon-muted)" },
    heat: { bg: "var(--avoid-bg)", fg: "var(--avoid)", ic: "var(--avoid)" },
    rain: { bg: "oklch(0.955 0.02 235)", fg: "var(--info)", ic: "var(--info)" },
    plain: { bg: "transparent", fg: "var(--text-muted)", ic: "var(--icon-muted)" },
  };
  const t = tones[tone] || tones.neutral;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      height: 28, padding: "0 11px", borderRadius: "var(--radius-pill)",
      background: t.bg, color: t.fg, border: tone === "plain" ? "1px solid var(--border-subtle)" : "1px solid transparent",
      fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", fontWeight: 600, ...style,
    }}>
      {icon && <span style={{ display: "flex", color: t.ic }}>{icon}</span>}
      {label}
    </span>
  );
}
