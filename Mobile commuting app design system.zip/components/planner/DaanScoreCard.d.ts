import * as React from "react";
import { WeatherChipProps } from "./WeatherChip";

export interface DaanScoreCardProps {
  /** Walkability score out of 100. @default 29 */
  score?: number;
  /** @default "avoid" */
  verdict?: "walkable" | "caution" | "avoid";
  /** Override the verdict pill text. */
  verdictLabel?: string;
  summary?: string;
  /** e.g. "1.1 km" */
  distance?: string;
  /** e.g. "15 min" */
  duration?: string;
  /** Environmental factor chips. */
  weather?: WeatherChipProps[];
  style?: React.CSSProperties;
}

/**
 * The verdict block for a route: big serif Daan score, walkable/caution/avoid
 * pill, one-line summary, distance→time, and weather-factor chips.
 * @startingPoint section="Planner" subtitle="Daan Score verdict card" viewport="700x320"
 */
export function DaanScoreCard(props: DaanScoreCardProps): JSX.Element;
