The route verdict block: large serif Daan Score /100, a walkable/caution/avoid pill, a one-line reason, distance→time, and weather-factor chips.

```jsx
<DaanScoreCard
  score={29} verdict="avoid"
  summary="Consider another way to travel. See the receipt for why."
  distance="1.1 km" duration="15 min"
  weather={[
    { tone:"heat", icon:<Icon name="thermometer-sun" />, label:"Feels like 41.2°C" },
    { tone:"rain", icon:<Icon name="cloud-rain" />, label:"20% rain" },
    { tone:"plain", label:"weather ×0.65" },
  ]}
/>
```

Verdict `walkable|caution|avoid` sets the pill color/icon.
