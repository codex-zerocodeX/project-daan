import React from "react";

/**
 * Alitaptap EvidenceCoverageBar — how much of a route has structural evidence.
 * Known portion runs the calm→gold gradient; the remainder is neutral "unknown".
 */
export function EvidenceCoverageBar({ coverage = 75, style = {} }) {
  const known = Math.max(0, Math.min(100, coverage));
  return (
    <div style={{ fontFamily: "var(--font-sans)", ...style }}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 8 }}>
        <span style={{ fontSize: "var(--text-body-md)", fontWeight: 700, color: "var(--text-strong)" }}>{known}% evidence coverage</span>
        <span style={{ fontSize: "var(--text-sm)", color: "var(--text-muted)" }}>
          <span style={{ fontWeight: 700, color: "var(--text-body)" }}>{100 - known}%</span> unknown
        </span>
      </div>
      <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
        <span style={{ width: `${known}%`, height: 10, borderRadius: "var(--radius-pill)", background: "var(--grad-evidence)" }} />
        <span style={{ flex: 1, height: 10, borderRadius: "var(--radius-pill)", background: "var(--paper-300)" }} />
      </div>
    </div>
  );
}
