import * as React from "react";

export interface RouteChoiceCardProps {
  icon?: React.ReactNode;
  title?: string;
  /** Profile score out of 100. */
  score?: number;
  /** e.g. "1.1 km" */
  distance?: string;
  /** e.g. "15 min" */
  duration?: string;
  /** e.g. "4 place" */
  places?: string;
  selected?: boolean;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  style?: React.CSSProperties;
}

/**
 * A selectable routing profile (Shortest time, Comfort balance). Selected fills navy.
 * Place two side by side in a "Route choice" row.
 * @startingPoint section="Planner" subtitle="Route profile selector" viewport="700x140"
 */
export function RouteChoiceCard(props: RouteChoiceCardProps): JSX.Element;
