import React from "react";

/** Alitaptap InfoBanner — full-width disclosure strip (e.g. live-data caveats). */
export function InfoBanner({ icon = null, children, tone = "notice", style = {} }) {
  const tones = {
    notice: { bg: "var(--glow-soft)", fg: "var(--navy-800)", ic: "var(--glow-600)" },
    neutral: { bg: "var(--surface-sunken)", fg: "var(--text-body)", ic: "var(--icon-muted)" },
  };
  const t = tones[tone] || tones.notice;
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 9,
      padding: "8px 20px", background: t.bg, color: t.fg,
      fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", fontWeight: 500, ...style,
    }}>
      <span style={{ display: "flex", color: t.ic, flex: "none" }}>
        {icon || <span style={{ width: 15, height: 15, borderRadius: "50%", border: `1.5px solid ${t.ic}`, display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700 }}>i</span>}
      </span>
      <span>{children}</span>
    </div>
  );
}
