import * as React from "react";

export interface FireflyPanelProps {
  title?: string;
  subtitle?: string;
  /** Path to the firefly hero image (relative to the consuming page). */
  image?: string;
  height?: number;
  style?: React.CSSProperties;
}

/**
 * Dark night-panel with the glowing firefly + light trail; the brand's signature
 * empty/prompt state. Pass `image` as the correct relative path to firefly-hero.png.
 * @startingPoint section="Planner" subtitle="Firefly night prompt panel" viewport="700x120"
 */
export function FireflyPanel(props: FireflyPanelProps): JSX.Element;
