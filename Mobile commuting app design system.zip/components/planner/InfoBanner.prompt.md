Full-width strip for disclosures and data-freshness notices, shown under the app header.

```jsx
<InfoBanner>Live data unavailable — showing the disclosed route fixture captured at 1:55 PM.</InfoBanner>
```

Tones `notice` (soft gold) or `neutral`.
