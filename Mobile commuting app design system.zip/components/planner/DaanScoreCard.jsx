import React from "react";
import { WeatherChip } from "./WeatherChip.jsx";

/**
 * Alitaptap DaanScoreCard — the verdict block. Big serif score /100, a
 * calm/avoid verdict badge, one-line summary, distance→time, weather factors.
 */
export function DaanScoreCard({
  score = 29,
  verdict = "avoid",       // "walkable" | "caution" | "avoid"
  verdictLabel,
  summary = "Consider another way to travel. See the receipt for why.",
  distance,
  duration,
  weather = [],
  style = {},
}) {
  const V = {
    walkable: { fg: "var(--calm)", label: "WALKABLE", icon: "✓" },
    caution: { fg: "oklch(0.52 0.11 62)", label: "CAUTION", icon: "!" },
    avoid: { fg: "var(--avoid)", label: "AVOID", icon: "✕" },
  }[verdict] || {};
  return (
    <div style={{ fontFamily: "var(--font-sans)", display: "flex", flexDirection: "column", gap: 14, ...style }}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: "var(--text-2xs)", fontWeight: 700, textTransform: "uppercase", letterSpacing: "var(--tracking-label)", color: "var(--text-muted)", marginBottom: 4 }}>Daan score</div>
          <div style={{ fontFamily: "var(--font-serif)", fontWeight: 700, fontSize: "var(--score-lg)", lineHeight: 1, color: "var(--text-strong)" }}>
            {score}<span style={{ fontFamily: "var(--font-sans)", fontSize: 20, fontWeight: 500, color: "var(--text-muted)" }}> /100</span>
          </div>
        </div>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "4px 11px", borderRadius: "var(--radius-pill)", background: "transparent", border: `1px solid ${V.fg}`, color: V.fg, fontSize: "var(--text-sm)", fontWeight: 700, letterSpacing: "0.02em" }}>
          <span style={{ width: 16, height: 16, borderRadius: "50%", border: `1.5px solid ${V.fg}`, display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 10 }}>{V.icon}</span>
          {verdictLabel || V.label}
        </span>
      </div>

      <p style={{ margin: 0, fontSize: "var(--text-body-md)", lineHeight: "var(--leading-normal)", color: "var(--text-body)", textWrap: "pretty" }}>{summary}</p>

      {(distance || duration) && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, paddingTop: 12, borderTop: "1px solid var(--border-subtle)", fontFamily: "var(--font-mono)", fontSize: "var(--text-body-md)", color: "var(--text-body)" }}>
          {distance && <span>{distance}</span>}
          {distance && duration && <span style={{ color: "var(--text-muted)" }}>→</span>}
          {duration && <span>{duration}</span>}
        </div>
      )}

      {weather.length > 0 && (
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {weather.map((w, i) => <WeatherChip key={i} {...w} />)}
        </div>
      )}
    </div>
  );
}
