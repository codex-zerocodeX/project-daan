Small chip for an environmental factor affecting a walk score.

```jsx
<WeatherChip tone="heat" icon={<Icon name="thermometer-sun" />} label="Feels like 41.2°C" />
<WeatherChip tone="rain" icon={<Icon name="cloud-rain" />} label="20% rain" />
<WeatherChip tone="plain" label="weather ×0.65" />
```

Tones `neutral|heat|rain|plain`.
