import React from "react";

/** Lakbay IconButton — square/circular tap target for a single glyph. */
export function IconButton({
  children,
  variant = "surface",
  size = "md",
  round = false,
  disabled = false,
  ariaLabel,
  onClick,
  style = {},
  ...rest
}) {
  const sizes = { sm: 34, md: 40, lg: 48 };
  const dim = sizes[size] || sizes.md;
  const variants = {
    surface: { background: "var(--surface-raised)", color: "var(--icon-default)", border: "1px solid var(--border-subtle)", boxShadow: "var(--shadow-xs)" },
    primary: { background: "var(--navy-900)", color: "var(--text-on-navy)", border: "1px solid transparent", boxShadow: "var(--shadow-sm)" },
    ghost: { background: "transparent", color: "var(--icon-default)", border: "1px solid transparent" },
  };
  const v = variants[variant] || variants.surface;
  return (
    <button
      type="button"
      aria-label={ariaLabel}
      disabled={disabled}
      onClick={disabled ? undefined : onClick}
      style={{
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        width: dim, height: dim, flex: "none",
        borderRadius: round ? "var(--radius-pill)" : "var(--radius-sm)",
        cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.45 : 1,
        transition: "transform var(--dur-fast) var(--ease-standard)",
        WebkitTapHighlightColor: "transparent", ...v, ...style,
      }}
      onMouseDown={(e) => { if (!disabled) e.currentTarget.style.transform = "scale(0.92)"; }}
      onMouseUp={(e) => { e.currentTarget.style.transform = "scale(1)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.transform = "scale(1)"; }}
      {...rest}
    >
      {children}
    </button>
  );
}
