Rounded text field with optional leading icon; the origin and destination search fields are built from it.

```jsx
<Input leadingIcon={<Icon name="search" />} placeholder="Where to?" value={dest} onChange={e => setDest(e.target.value)} />
```

Sizes `md|lg` (48/56px). `invalid` turns the border alert-red. Put a clear button or place chip in `trailingSlot`.
