import * as React from "react";

export interface BadgeProps {
  children?: React.ReactNode;
  /** @default "neutral" */
  tone?: "neutral" | "primary" | "good" | "warn" | "alert";
  /** Filled vs soft-tint. @default false */
  solid?: boolean;
  leadingIcon?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Compact status/label pill (Recommended, Delayed, +2 transfers). */
export function Badge(props: BadgeProps): JSX.Element;
