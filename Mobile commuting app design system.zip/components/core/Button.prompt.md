Pill-shaped primary action control; use for the main call-to-action on any screen (Find routes, Write a review, Get directions).

```jsx
<Button variant="primary" size="lg" fullWidth onClick={search}>Find routes</Button>
<Button variant="outline" leadingIcon={<Icon name="star" />}>Save</Button>
```

Variants: `primary` (filled teal), `secondary` (soft tint), `outline` (bordered), `ghost` (text-only). Sizes `sm|md|lg`. Always ≥44px tall at `md`/`lg` for touch.
