Pill-shaped primary action control; use for the main call-to-action on any screen (Find routes, Write a review, Get directions).

```jsx
<Button variant="primary" size="lg" fullWidth onClick={search}>Find routes</Button>
<Button variant="outline" leadingIcon={<Icon name="star" />}>Save</Button>
```

Variants: `primary` (navy ink), `accent` (firefly gold), `outline` (bordered on paper), `ghost` (text-only). Sizes `sm|md|lg`. Gently squared (radius-sm), not pill.
