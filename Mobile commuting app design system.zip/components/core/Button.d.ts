import * as React from "react";

export interface ButtonProps {
  children?: React.ReactNode;
  /** Visual emphasis. @default "primary" */
  variant?: "primary" | "accent" | "outline" | "ghost";
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  fullWidth?: boolean;
  disabled?: boolean;
  leadingIcon?: React.ReactNode;
  trailingIcon?: React.ReactNode;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  style?: React.CSSProperties;
}

/**
 * Primary tappable action. Pill-shaped, min 44px tall for touch.
 * @startingPoint section="Core" subtitle="Pill action button, 4 variants" viewport="700x160"
 */
export function Button(props: ButtonProps): JSX.Element;
