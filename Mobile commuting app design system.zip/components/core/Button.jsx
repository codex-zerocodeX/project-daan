import React from "react";

/**
 * Lakbay Button — primary action control. Calm, rounded, soft-elevated.
 */
export function Button({
  children,
  variant = "primary",
  size = "md",
  fullWidth = false,
  disabled = false,
  leadingIcon = null,
  trailingIcon = null,
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: { height: 36, padding: "0 14px", font: "var(--text-sm)", gap: 6 },
    md: { height: 44, padding: "0 18px", font: "var(--text-body-md)", gap: 8 },
    lg: { height: 52, padding: "0 22px", font: "var(--text-body-lg)", gap: 8 },
  };
  const variants = {
    primary: {
      background: "var(--primary-500)",
      color: "var(--text-on-primary)",
      border: "1px solid transparent",
      boxShadow: "var(--shadow-sm)",
    },
    secondary: {
      background: "var(--surface-primary-soft)",
      color: "var(--primary-700)",
      border: "1px solid transparent",
    },
    outline: {
      background: "var(--surface-card)",
      color: "var(--text-strong)",
      border: "1px solid var(--border-strong)",
    },
    ghost: {
      background: "transparent",
      color: "var(--primary-600)",
      border: "1px solid transparent",
    },
  };
  const s = sizes[size] || sizes.md;
  const v = variants[variant] || variants.primary;
  return (
    <button
      type="button"
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: s.gap,
        height: s.height,
        minWidth: s.height,
        padding: s.padding,
        width: fullWidth ? "100%" : "auto",
        fontFamily: "var(--font-sans)",
        fontSize: s.font,
        fontWeight: 600,
        lineHeight: 1,
        borderRadius: "var(--radius-pill)",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.45 : 1,
        transition: "transform var(--dur-fast) var(--ease-standard), filter var(--dur-fast) var(--ease-standard)",
        WebkitTapHighlightColor: "transparent",
        ...v,
        ...style,
      }}
      onMouseDown={(e) => { if (!disabled) e.currentTarget.style.transform = "scale(0.97)"; }}
      onMouseUp={(e) => { e.currentTarget.style.transform = "scale(1)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.transform = "scale(1)"; }}
      {...rest}
    >
      {leadingIcon}
      {children}
      {trailingIcon}
    </button>
  );
}
