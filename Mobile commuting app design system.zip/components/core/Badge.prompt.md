Small pill for status and labels; tones reuse the crowd/reliability status colors.

```jsx
<Badge tone="accent">Metro Manila</Badge>
<Badge tone="avoid" leadingIcon={<Icon name="x-circle" />}>Avoid</Badge>
```

Tones `neutral|primary|accent|calm|moderate|avoid`. `solid` for a filled emphasis pill.
