Small pill for status and labels; tones reuse the crowd/reliability status colors.

```jsx
<Badge tone="primary">Recommended</Badge>
<Badge tone="alert" solid>Delayed</Badge>
```

Tones `neutral|primary|good|warn|alert`. `solid` for a filled emphasis pill.
