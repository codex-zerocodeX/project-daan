import * as React from "react";

export interface CardProps {
  children?: React.ReactNode;
  /** Adds hover lift + pointer cursor. @default false */
  interactive?: boolean;
  padding?: string;
  /** @default "card" */
  elevation?: "none" | "xs" | "card" | "lifted";
  onClick?: (e: React.MouseEvent<HTMLDivElement>) => void;
  style?: React.CSSProperties;
}

/** Rounded soft-elevated surface; base container for route and review cards. */
export function Card(props: CardProps): JSX.Element;
