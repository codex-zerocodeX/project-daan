import * as React from "react";

export interface IconButtonProps {
  children?: React.ReactNode;
  /** @default "surface" */
  variant?: "surface" | "primary" | "ghost";
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** Pill vs rounded-square. @default false */
  round?: boolean;
  disabled?: boolean;
  ariaLabel?: string;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  style?: React.CSSProperties;
}

/** Single-glyph tap target (back, locate-me, favorite). Always pass ariaLabel. */
export function IconButton(props: IconButtonProps): JSX.Element;
