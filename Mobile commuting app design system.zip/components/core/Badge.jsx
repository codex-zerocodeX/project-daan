import React from "react";

/** Lakbay Badge — small status/label pill. Tones map to the status token set. */
export function Badge({ children, tone = "neutral", solid = false, leadingIcon = null, style = {} }) {
  const map = {
    neutral: { soft: "var(--surface-sunken)", fg: "var(--text-muted)", solidBg: "var(--navy-700)" },
    primary: { soft: "var(--paper-200)", fg: "var(--navy-800)", solidBg: "var(--navy-900)" },
    accent: { soft: "var(--glow-soft)", fg: "var(--glow-600)", solidBg: "var(--glow-500)" },
    calm: { soft: "var(--calm-bg)", fg: "var(--calm)", solidBg: "var(--calm)" },
    moderate: { soft: "var(--moderate-bg)", fg: "oklch(0.52 0.11 62)", solidBg: "var(--moderate)" },
    avoid: { soft: "var(--avoid-bg)", fg: "var(--avoid)", solidBg: "var(--avoid)" },
  };
  const t = map[tone] || map.neutral;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "3px 10px", borderRadius: "var(--radius-pill)",
      fontFamily: "var(--font-sans)", fontSize: "var(--text-xs)", fontWeight: 700,
      letterSpacing: "0.01em", lineHeight: 1.4,
      background: solid ? t.solidBg : t.soft,
      color: solid ? (tone === "accent" ? "var(--navy-900)" : "var(--text-on-navy)") : t.fg, ...style,
    }}>
      {leadingIcon}
      {children}
    </span>
  );
}
