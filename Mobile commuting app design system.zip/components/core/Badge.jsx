import React from "react";

/** Lakbay Badge — small status/label pill. Tones map to the status token set. */
export function Badge({ children, tone = "neutral", solid = false, leadingIcon = null, style = {} }) {
  const map = {
    neutral: { soft: "var(--surface-sunken)", fg: "var(--text-muted)", solidBg: "var(--neutral-700)" },
    primary: { soft: "var(--surface-primary-soft)", fg: "var(--primary-700)", solidBg: "var(--primary-500)" },
    good: { soft: "var(--status-good-bg)", fg: "var(--status-good)", solidBg: "var(--status-good)" },
    warn: { soft: "var(--status-warn-bg)", fg: "oklch(0.5 0.09 75)", solidBg: "var(--status-warn)" },
    alert: { soft: "var(--status-alert-bg)", fg: "var(--status-alert)", solidBg: "var(--status-alert)" },
  };
  const t = map[tone] || map.neutral;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "3px 10px", borderRadius: "var(--radius-pill)",
      fontFamily: "var(--font-sans)", fontSize: "var(--text-xs)", fontWeight: 700,
      letterSpacing: "0.01em", lineHeight: 1.4,
      background: solid ? t.solidBg : t.soft,
      color: solid ? "var(--text-on-primary)" : t.fg, ...style,
    }}>
      {leadingIcon}
      {children}
    </span>
  );
}
