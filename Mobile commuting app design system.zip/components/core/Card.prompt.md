Rounded, softly-shadowed surface; the container every list item and panel sits in.

```jsx
<Card interactive onClick={open}>…</Card>
```

`elevation` `none|xs|card|lifted`. `interactive` adds a gentle hover lift — use for tappable list rows.
