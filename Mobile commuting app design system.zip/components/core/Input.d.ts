import * as React from "react";

export interface InputProps {
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  leadingIcon?: React.ReactNode;
  /** Right-side element: clear button, "Home" chip, etc. */
  trailingSlot?: React.ReactNode;
  /** @default "md" */
  size?: "md" | "lg";
  invalid?: boolean;
  disabled?: boolean;
  style?: React.CSSProperties;
}

/** Single-line text field; the origin/destination entry fields build on this. */
export function Input(props: InputProps): JSX.Element;
