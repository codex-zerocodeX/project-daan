Circular or rounded-square button holding one icon; use for map controls, nav back/close, and favorite toggles.

```jsx
<IconButton ariaLabel="Locate me" variant="surface"><Icon name="locate-fixed" /></IconButton>
```

Variants `surface|primary|ghost`; sizes `sm|md|lg` (36/44/52px). Set `round={false}` for a squircle. Always provide `ariaLabel`.
