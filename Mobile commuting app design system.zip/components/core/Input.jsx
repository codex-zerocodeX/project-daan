import React from "react";

/** Lakbay Input — text field with optional leading icon, used for search + place entry. */
export function Input({
  value,
  onChange,
  placeholder = "",
  leadingIcon = null,
  trailingSlot = null,
  size = "md",
  invalid = false,
  disabled = false,
  style = {},
  ...rest
}) {
  const sizes = { md: 48, lg: 56 };
  const h = sizes[size] || sizes.md;
  const [focused, setFocused] = React.useState(false);
  return (
    <div
      style={{
        display: "flex", alignItems: "center", gap: 10,
        height: h, padding: "0 14px",
        background: disabled ? "var(--surface-sunken)" : "var(--surface-card)",
        border: `1px solid ${invalid ? "var(--status-alert)" : focused ? "var(--border-focus)" : "var(--border-subtle)"}`,
        borderRadius: "var(--radius-md)",
        boxShadow: focused ? "var(--ring-focus)" : "var(--shadow-xs)",
        transition: "border-color var(--dur-fast), box-shadow var(--dur-fast)",
        opacity: disabled ? 0.6 : 1, ...style,
      }}
    >
      {leadingIcon && <span style={{ display: "flex", color: "var(--icon-default)", flex: "none" }}>{leadingIcon}</span>}
      <input
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        disabled={disabled}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          flex: 1, minWidth: 0, border: "none", outline: "none", background: "transparent",
          fontFamily: "var(--font-sans)", fontSize: "var(--text-body-md)", fontWeight: 500,
          color: "var(--text-strong)",
        }}
        {...rest}
      />
      {trailingSlot}
    </div>
  );
}
