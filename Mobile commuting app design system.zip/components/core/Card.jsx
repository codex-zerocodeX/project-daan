import React from "react";

/** Lakbay Card — soft surface container. The base for route + review cards. */
export function Card({ children, interactive = false, padding = "var(--space-4)", elevation = "card", style = {}, onClick, ...rest }) {
  const shadows = { none: "none", xs: "var(--shadow-xs)", card: "var(--shadow-card)", lifted: "var(--shadow-lifted)" };
  return (
    <div
      onClick={onClick}
      style={{
        background: "var(--surface-card)",
        border: "1px solid var(--border-subtle)",
        borderRadius: "var(--radius-lg)",
        boxShadow: shadows[elevation] || shadows.card,
        padding,
        cursor: interactive ? "pointer" : "default",
        transition: "transform var(--dur-med) var(--ease-emphasized), box-shadow var(--dur-med) var(--ease-standard)",
        ...style,
      }}
      onMouseEnter={interactive ? (e) => { e.currentTarget.style.boxShadow = "var(--shadow-lifted)"; e.currentTarget.style.transform = "translateY(-2px)"; } : undefined}
      onMouseLeave={interactive ? (e) => { e.currentTarget.style.boxShadow = shadows[elevation] || shadows.card; e.currentTarget.style.transform = "translateY(0)"; } : undefined}
      {...rest}
    >
      {children}
    </div>
  );
}
