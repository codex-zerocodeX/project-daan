import * as React from "react";

export interface ModeBadgeProps {
  /** @default "bus" */
  mode?: "bus" | "walk" | "transfer";
  /** Override label, e.g. a route name "EDSA Carousel". */
  label?: string;
  icon?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Chip identifying a transport leg's mode. Bus is filled/primary; walk is neutral. */
export function ModeBadge(props: ModeBadgeProps): JSX.Element;
