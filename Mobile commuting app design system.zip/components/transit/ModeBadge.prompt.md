Chip labelling a transport leg by mode; bus renders filled/primary, walk renders neutral.

```jsx
<ModeBadge mode="bus" label="EDSA Carousel" icon={<Icon name="bus" />} />
<ModeBadge mode="walk" label="400 m" />
```
