import React from "react";
import { CrowdMeter } from "./CrowdMeter.jsx";

/** Lakbay ReviewCard — a single rider's review of a route. */
export function ReviewCard({
  author,
  avatarColor = "var(--primary-200)",
  timeAgo,
  rating = 5,
  comment,
  crowdLevel,
  reliability,
  walkability,
  helpfulCount,
  style = {},
}) {
  const chips = [];
  if (crowdLevel != null) chips.push({ label: "Crowd", node: <CrowdMeter level={crowdLevel} size="sm" showLabel={false} /> });
  const pill = (label, value, tone) => {
    const bg = { good: "var(--status-good-bg)", warn: "var(--status-warn-bg)", alert: "var(--status-alert-bg)" }[tone] || "var(--surface-sunken)";
    const fg = { good: "var(--status-good)", warn: "oklch(0.5 0.09 75)", alert: "var(--status-alert)" }[tone] || "var(--text-muted)";
    return (
      <span style={{ display: "inline-flex", flexDirection: "column", gap: 2, padding: "6px 10px", borderRadius: "var(--radius-sm)", background: bg }}>
        <span style={{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: "var(--text-muted)" }}>{label}</span>
        <span style={{ fontSize: "var(--text-sm)", fontWeight: 700, color: fg }}>{value}</span>
      </span>
    );
  };
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12, fontFamily: "var(--font-sans)", padding: "var(--space-4)", background: "var(--surface-card)", border: "1px solid var(--border-subtle)", borderRadius: "var(--radius-lg)", boxShadow: "var(--shadow-xs)", ...style }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span style={{ width: 38, height: 38, borderRadius: "50%", background: avatarColor, color: "var(--primary-700)", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 15, flex: "none" }}>
          {(author || "?").charAt(0).toUpperCase()}
        </span>
        <div style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
          <span style={{ fontWeight: 600, fontSize: "var(--text-body-md)", color: "var(--text-strong)" }}>{author}</span>
          <span style={{ fontSize: "var(--text-sm)", color: "var(--text-muted)" }}>{timeAgo}</span>
        </div>
        <span style={{ marginLeft: "auto", display: "inline-flex", alignItems: "center", gap: 4, fontWeight: 700, fontSize: "var(--text-body-md)", color: "var(--text-strong)" }}>
          <span style={{ color: "var(--status-warn)" }}>★</span>{rating}
        </span>
      </div>

      {comment && <p style={{ margin: 0, fontSize: "var(--text-body-md)", lineHeight: "var(--leading-normal)", color: "var(--text-body)", textWrap: "pretty" }}>{comment}</p>}

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
        {crowdLevel != null && (
          <span style={{ display: "inline-flex", flexDirection: "column", gap: 4, padding: "6px 10px", borderRadius: "var(--radius-sm)", background: "var(--surface-sunken)" }}>
            <span style={{ fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em", color: "var(--text-muted)" }}>Crowd</span>
            <CrowdMeter level={crowdLevel} size="sm" showLabel={false} />
          </span>
        )}
        {reliability && pill("Reliability", reliability.value, reliability.tone)}
        {walkability && pill("Walkability", walkability.value, walkability.tone)}
      </div>

      {helpfulCount != null && (
        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: "var(--text-sm)", color: "var(--text-muted)", fontWeight: 600 }}>
          <span>👍</span> Helpful · {helpfulCount}
        </div>
      )}
    </div>
  );
}
