import React from "react";

/**
 * Lakbay CrowdMeter — 4-segment fill showing how packed a route usually is.
 * level 1 = empty/light … 4 = packed. Color shifts good→warn→alert.
 */
export function CrowdMeter({ level = 2, showLabel = true, size = "md", style = {} }) {
  const clamped = Math.max(1, Math.min(4, level));
  const labels = { 1: "Seats free", 2: "Light crowd", 3: "Moderate", 4: "Packed" };
  const color = clamped <= 1 ? "var(--status-good)" : clamped === 2 ? "var(--status-good)" : clamped === 3 ? "var(--status-warn)" : "var(--status-alert)";
  const dims = size === "sm" ? { w: 10, h: 12, gap: 3 } : { w: 14, h: 16, gap: 4 };
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 8, ...style }}>
      <span style={{ display: "inline-flex", gap: dims.gap, alignItems: "flex-end" }}>
        {[1, 2, 3, 4].map((i) => (
          <span key={i} style={{
            width: dims.w, height: dims.h * (0.55 + i * 0.15),
            borderRadius: 3,
            background: i <= clamped ? color : "var(--neutral-200)",
            transition: "background var(--dur-med) var(--ease-standard)",
          }} />
        ))}
      </span>
      {showLabel && <span style={{ fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", fontWeight: 600, color: "var(--text-body)" }}>{labels[clamped]}</span>}
    </span>
  );
}
