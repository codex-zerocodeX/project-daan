import * as React from "react";

export interface RouteLeg {
  mode: "bus" | "walk" | "transfer";
  label?: string;
  icon?: React.ReactNode;
}

export interface RouteCardProps {
  title?: string;
  /** Ordered transport legs shown as mode chips. */
  legs?: RouteLeg[];
  /** e.g. "38 min" */
  duration?: string;
  /** e.g. "₱15" */
  fare?: string;
  /** Aggregate rider score, e.g. 4.3 */
  score?: number;
  reviewCount?: number;
  /** Typical crowdedness 1–4. @default 2 */
  crowdLevel?: 1 | 2 | 3 | 4;
  /** Reliability label, e.g. "On time", "Often delayed". */
  reliability?: string;
  /** @default "good" */
  reliabilityTone?: "good" | "warn" | "alert";
  /** Walking summary, e.g. "8 min". */
  walk?: string;
  recommended?: boolean;
  /** Flag when this route serves a *nearby* destination, not the exact one. */
  similar?: boolean;
  onClick?: (e: React.MouseEvent<HTMLDivElement>) => void;
  style?: React.CSSProperties;
}

/**
 * One route option in the results list: legs, time, fare, crowd, reliability, walk, score.
 * @startingPoint section="Transit" subtitle="Route option with review summary" viewport="700x260"
 */
export function RouteCard(props: RouteCardProps): JSX.Element;
