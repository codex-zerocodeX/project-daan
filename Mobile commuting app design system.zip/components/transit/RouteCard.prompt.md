The primary results-list item: a full route option summarizing legs, time, fare, and the aggregated rider signals (crowd, reliability, walk, score).

```jsx
<RouteCard
  legs={[{mode:"walk",label:"5 min"},{mode:"bus",label:"EDSA Carousel"},{mode:"walk",label:"3 min"}]}
  duration="38 min" fare="₱15" score={4.3} reviewCount={128}
  crowdLevel={2} reliability="On time" reliabilityTone="good" walk="8 min"
  recommended onClick={openDetail}
/>
```

Set `similar` when the route serves a nearby destination rather than the exact one searched — pairs with the "same origin, nearby destination" fallback.
