import * as React from "react";

export interface ReviewSignal {
  /** Short display value, e.g. "On time", "Easy". */
  value: string;
  tone?: "good" | "warn" | "alert";
}

export interface ReviewCardProps {
  author?: string;
  avatarColor?: string;
  /** e.g. "2 days ago" */
  timeAgo?: string;
  /** 1–5 */
  rating?: number;
  comment?: string;
  /** Rider's crowd read, 1–4. */
  crowdLevel?: 1 | 2 | 3 | 4;
  reliability?: ReviewSignal;
  walkability?: ReviewSignal;
  helpfulCount?: number;
  style?: React.CSSProperties;
}

/**
 * A single rider review: author, rating, comment, and the three route signals
 * (crowd, reliability, walkability). Listed under each route.
 * @startingPoint section="Transit" subtitle="Rider review with route signals" viewport="700x300"
 */
export function ReviewCard(props: ReviewCardProps): JSX.Element;
