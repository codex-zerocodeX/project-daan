Rising-bars indicator for how crowded a route usually is, aggregated from rider reviews.

```jsx
<CrowdMeter level={3} />          // "Moderate", amber
<CrowdMeter level={1} size="sm" showLabel={false} />
```

Level 1–4 (seats free → packed). Color: 1–2 good/green, 3 warn/amber, 4 alert/red.
