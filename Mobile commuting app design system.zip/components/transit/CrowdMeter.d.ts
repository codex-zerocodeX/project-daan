import * as React from "react";

export interface CrowdMeterProps {
  /** 1 (seats free) … 4 (packed). @default 2 */
  level?: 1 | 2 | 3 | 4;
  /** Show the text label beside the bars. @default true */
  showLabel?: boolean;
  /** @default "md" */
  size?: "sm" | "md";
  style?: React.CSSProperties;
}

/**
 * Four rising bars showing typical crowdedness; color shifts good→warn→alert.
 * @startingPoint section="Transit" subtitle="Crowdedness indicator, 4 levels" viewport="700x120"
 */
export function CrowdMeter(props: CrowdMeterProps): JSX.Element;
