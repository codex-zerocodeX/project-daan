import React from "react";
import { CrowdMeter } from "./CrowdMeter.jsx";
import { ModeBadge } from "./ModeBadge.jsx";

/**
 * Lakbay RouteCard — one route option in the results list.
 * Shows mode legs, time, fare, rider score, crowd + reliability + walk summary.
 */
export function RouteCard({
  title,
  legs = [],
  duration,
  fare,
  score,
  reviewCount,
  crowdLevel = 2,
  reliability = "On time",
  reliabilityTone = "good",
  walk,
  recommended = false,
  similar = false,
  onClick,
  style = {},
}) {
  const relColors = { good: "var(--status-good)", warn: "var(--status-warn)", alert: "var(--status-alert)" };
  return (
    <div
      onClick={onClick}
      style={{
        background: "var(--surface-card)", border: `1px solid ${recommended ? "var(--primary-200)" : "var(--border-subtle)"}`,
        borderRadius: "var(--radius-lg)", boxShadow: "var(--shadow-card)", padding: "var(--space-4)",
        cursor: onClick ? "pointer" : "default", display: "flex", flexDirection: "column", gap: 12,
        fontFamily: "var(--font-sans)", ...style,
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
            {legs.map((l, i) => (
              <React.Fragment key={i}>
                <ModeBadge mode={l.mode} label={l.label} icon={l.icon} />
                {i < legs.length - 1 && <span style={{ color: "var(--neutral-400)", fontSize: 14 }}>›</span>}
              </React.Fragment>
            ))}
          </div>
          {title && <span style={{ fontSize: "var(--text-h3)", fontWeight: 600, color: "var(--text-strong)" }}>{title}</span>}
        </div>
        <div style={{ textAlign: "right", flex: "none" }}>
          <div style={{ fontFamily: "var(--font-mono)", fontWeight: 500, fontSize: 22, color: "var(--text-strong)" }}>{duration}</div>
          {fare != null && <div style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--text-muted)" }}>{fare}</div>}
        </div>
      </div>

      <div style={{ height: 1, background: "var(--border-subtle)" }} />

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <CrowdMeter level={crowdLevel} size="sm" />
        <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: "var(--text-sm)", fontWeight: 600, color: relColors[reliabilityTone] || "var(--text-body)" }}>
          <span style={{ width: 7, height: 7, borderRadius: "50%", background: relColors[reliabilityTone] || "var(--text-muted)" }} />
          {reliability}
        </span>
        {walk && <span style={{ fontSize: "var(--text-sm)", color: "var(--text-muted)", fontWeight: 500 }}>{walk} walk</span>}
        {score != null && (
          <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: "var(--text-sm)", fontWeight: 700, color: "var(--text-strong)" }}>
            <span style={{ color: "var(--status-warn)" }}>★</span>{score}
            {reviewCount != null && <span style={{ color: "var(--text-muted)", fontWeight: 500 }}>({reviewCount})</span>}
          </span>
        )}
      </div>

      {(recommended || similar) && (
        <div style={{ display: "flex", gap: 6 }}>
          {recommended && <span style={{ padding: "3px 10px", borderRadius: "var(--radius-pill)", background: "var(--surface-primary-soft)", color: "var(--primary-700)", fontSize: "var(--text-xs)", fontWeight: 700 }}>Recommended</span>}
          {similar && <span style={{ padding: "3px 10px", borderRadius: "var(--radius-pill)", background: "var(--surface-sunken)", color: "var(--text-muted)", fontSize: "var(--text-xs)", fontWeight: 700 }}>Nearby destination</span>}
        </div>
      )}
    </div>
  );
}
