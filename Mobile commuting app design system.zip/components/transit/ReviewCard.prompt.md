A single rider's review shown under a route: header (avatar, name, time, star rating), free-text comment, and the three structured signals — crowd, reliability, walkability.

```jsx
<ReviewCard
  author="Marco R." timeAgo="2 days ago" rating={4}
  comment="Calm before 7am, seats most days. Driver waits at the stop."
  crowdLevel={2}
  reliability={{ value: "On time", tone: "good" }}
  walkability={{ value: "Easy", tone: "good" }}
  helpfulCount={12}
/>
```
