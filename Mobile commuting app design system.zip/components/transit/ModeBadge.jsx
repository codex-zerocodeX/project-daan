import React from "react";

/** Lakbay ModeBadge — transport-mode chip. Bus is the primary mode; walk shown for legs. */
export function ModeBadge({ mode = "bus", label, icon = null, style = {} }) {
  const modes = {
    bus: { bg: "var(--primary-500)", fg: "var(--text-on-primary)", text: "Bus" },
    walk: { bg: "var(--surface-sunken)", fg: "var(--text-body)", text: "Walk" },
    transfer: { bg: "var(--surface-primary-soft)", fg: "var(--primary-700)", text: "Transfer" },
  };
  const m = modes[mode] || modes.bus;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      height: 26, padding: "0 10px", borderRadius: "var(--radius-sm)",
      background: m.bg, color: m.fg,
      fontFamily: "var(--font-sans)", fontSize: "var(--text-xs)", fontWeight: 700,
      letterSpacing: "0.01em", ...style,
    }}>
      {icon}
      {label || m.text}
    </span>
  );
}
