# Alitaptap Design System

**Alitaptap** (Filipino: *firefly*) is an **evidence guide for the way ahead** — a walkability planner for Metro Manila. A rider enters an **origin** and **destination**; Alitaptap scores each candidate route with a **Daan Score /100** (*daan* = road/way) built from structural evidence, community reviews, and live-ish conditions (heat, rain). When no route matches exactly, it keeps the **same origin** and surfaces routes ending at **nearby places**. The firefly is the guide that lights the path; its glowing trail is the brand's signature motif.

- **Surface:** responsive web app (desktop-first control panel + map)
- **Core metric:** Daan Score (0–100) with a walkable / caution / **AVOID** verdict
- **Tone:** friendly, plainspoken, evidence-honest ("Unknown is not scored and never hidden.")
- **Aesthetic:** firefly night — deep navy + warm cream paper + firefly-gold glow; editorial serif display

> **Brand assets provided** by the user (firefly renders). The logo is the **firefly mark** (`assets/firefly-mark.png`) paired with the wordmark set in Newsreader — "Alitaptap" (product) and "Daan" (score). No standalone glyph logo was given beyond the firefly.

---

## Content fundamentals
Copy is **calm, direct, and evidence-forward** — it never overpromises and always discloses uncertainty.
- **Voice:** helpful and honest. "Find your way, then check it", "Consider another way to travel. See the receipt for why.", "Unknown is not scored and never hidden."
- **Casing:** serif sentence-case for headlines and the wordmark; small **UPPERCASE tracked labels** for sections (PLAN A WALK, FROM, TO, ROUTE CHOICE, DAAN SCORE).
- **Numbers:** front-and-center — the Daan Score is a large serif numeral; distances/times/temps in mono ("1.1 km", "15 min", "41.2 °C", "×0.65").
- **Disclosure:** always show data freshness and gaps (the info banner, "75% evidence coverage / 25% unknown"). Uncertainty is surfaced, not hidden.
- **Emoji:** none. Meaning is carried by icons + color.

## Visual foundations
- **Color:** deep navy night (`--navy-950/900`) for the header, dark panels, primary buttons, and serif ink; warm cream **paper** neutrals (`--paper-100` app bg, `--paper-50` cards, white for the map). Firefly **gold** (`--glow-500`) is the single accent — score bars, notices, the mark's glow. Status runs a calm→avoid scale: green `--calm`, amber `--moderate`, coral `--avoid`, plus `--info` blue for rain. Max two paper tones + navy per screen.
- **Type:** **Newsreader** (serif) for display, headlines, the wordmark, and the big Daan numeral; **Hanken Grotesk** (sans) for all UI, body, and uppercase micro-labels; **DM Mono** for measured data. Scale: display 36 / h1 26 / h2 20 / h3 17 / body 15–16 / label 11–12; score numeral 52.
- **Spacing/shape:** 4px grid, 20px gutter. Gently squared corners — buttons/inputs/chips `radius-sm` (8px), cards/panels `radius-lg` (14px), pills for status/factor chips.
- **Elevation:** soft, cool-tinted shadows on paper; a dedicated `--shadow-night` and `--glow-ring` for the firefly. Cards carry a 1px `--border-subtle` hairline.
- **Signature gradients:** `--grad-evidence` (calm→gold, evidence coverage) and `--grad-route` (calm→gold→amber→avoid, the map's comfort line).
- **Backgrounds/imagery:** warm cream paper; the map is a light basemap (real: OpenStreetMap/OpenFreeMap — placeholder here). The firefly hero (`assets/firefly-hero.png`) fills the dark night panels with its light trail.
- **Motion:** quick, gentle — 120ms press (scale 0.98), 220ms selection fills. Standard/emphasized easing; no bounce. Firefly may pulse subtly.
- **States:** selected route/segment fills navy; hover lifts cards; focus = navy-tinted ring; disabled 0.45 opacity.
- **Verdict language:** the AVOID/CAUTION/WALKABLE pill is outline + icon, colored by status — never a solid alarming block.

## Iconography
- **Set:** [Lucide](https://lucide.dev) — clean ~1.75px stroke, rounded joins. **Substitution flagged:** no icon assets were provided (Lucide via `lucide-react` in the UI kit, `unpkg.com/lucide` in cards). Common glyphs: `search`, `map-pin`, `arrow-up-down`, `clock`, `route`, `scale`, `x-circle`/`check-circle-2`/`alert-circle` (verdicts), `thermometer-sun`, `cloud-rain`, `shield-check`, `info`, `plus`/`minus`.
- **Brand mark:** the firefly render is used as the app mark; do not redraw it — use `assets/firefly-mark.png`.
- **Emoji:** none. **Unicode:** `→` for from→to, `×` for multipliers.

---

## Index / manifest
- `styles.css` — global entry; `@import`s all tokens + fonts.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `effects.css` (incl. signature gradients), `fonts.css`.
- `assets/` — `firefly-mark.png` (logo mark), `firefly-hero.png` (night-panel hero + trail), `reference-alitaptap.png` (source screenshot).
- `guidelines/` — specimen cards: Brand (logo), Colors (Navy, Paper, Glow & Status, Gradients), Type (Serif, Sans, Scores), Spacing (scale, radius & elevation).
- `components/core/` — **Button, IconButton, Input, Badge, Card**.
- `components/planner/` — the domain set: **SegmentedToggle, RouteChoiceCard, DaanScoreCard, EvidenceCoverageBar, WeatherChip, FireflyPanel, InfoBanner**.
- `ui_kits/alitaptap-app/` — **mobile** app flow (`index.html`): plan a walk → route results (Daan Score per route) → route detail (evidence, weather, trip, firefly panel, rider reviews) + nearby-destination fallback.
- `ui_kits/alitaptap-planner/` — **desktop** planner recreation (`index.html`).
- `SKILL.md` — Agent-Skill wrapper.

### Intentional additions
Built to match the provided design: the planner group (`DaanScoreCard`, `RouteChoiceCard`, `EvidenceCoverageBar`, `WeatherChip`, `FireflyPanel`, `InfoBanner`, `SegmentedToggle`) encodes the walkability/evidence concept these screens introduced.
