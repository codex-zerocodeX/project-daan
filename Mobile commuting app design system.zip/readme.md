# Lakbay Design System

**Lakbay** (Filipino: *journey*) is a design system for a mobile commuting app. Riders enter an **origin** and **destination**, and each candidate route is shown with **community reviews** — crowdedness, travel-time reliability, and walkability. When no route serves the exact destination, Lakbay keeps the **same origin** and surfaces routes ending at **nearby places** instead.

- **Platform:** neutral (works as iOS or Android)
- **Primary mode:** bus (extensible to jeepney, rail, ride-hail, walk legs)
- **Tone:** friendly & casual
- **Aesthetic:** calm & trustworthy — soft, muted transit blue/green

> No brand assets were provided; this system is generated from scratch. There is **no logo** — the brand name renders in plain type wherever a mark would go (see Iconography).

---

## Content fundamentals
Copy is **friendly, second-person, and low-pressure** — it talks to a tired commuter, not a power user.
- **Voice:** warm, plainspoken, reassuring. "Where to today?", "No exact match nearby?", "Same start, nearby drop-offs."
- **Person/casing:** address the rider as *you*; sentence case everywhere except small uppercase section labels (RECENT, CROWD). Never ALL-CAPS for emphasis in body copy.
- **Numbers:** concrete and scannable — "38 min", "₱15", "Usually 26 min", "8am". Times and fares always in the mono typeface.
- **Reviews read like a friend's tip:** "Calm before 7am, seats most days." Avoid corporate hedging.
- **Emoji:** used *very sparingly* — only 👍 on the "Helpful" affordance. Not in headings, buttons, or body copy.

## Visual foundations
- **Color:** cool-toned neutrals (near-white `--neutral-50` app bg, `--neutral-900` text). Muted teal-blue primary (`--primary-500`, oklch ~0.60/0.10/201) for actions and bus legs. Supportive green accent for "go". Status hues share ~0.10 chroma — green (light crowd / on time), amber (moderate), red (packed / delayed). Max two background tones per screen (app bg + card white).
- **Type:** **Plus Jakarta Sans** for all UI, headings, and body (friendly geometric sans); **DM Mono** for data — times, fares, distances, ratings. Display 32 / H1 24 / H2 20 / H3 17 / body 15–16 / caption 13 / label 11. Tight tracking on large headings; wide tracking + uppercase on 11px labels.
- **Spacing:** 4px base grid; 16px default screen gutter. Minimum 44px touch targets.
- **Corners:** inputs/chips 12px, cards 16px, sheets/hero cards 22px, buttons & badges fully pill.
- **Elevation:** soft, low-contrast, cool-tinted shadows — never harsh. `--shadow-card` on list items, `--shadow-lifted` on the search sheet and route hero. Cards also carry a 1px `--border-subtle` hairline.
- **Backgrounds/imagery:** map areas are striped placeholders (drop in a real map SDK); route lines are muted teal/green over a light basemap. No photography, no gradients-as-decoration.
- **Motion:** quick and gentle — 120ms press (scale 0.97), 200ms hover lift on interactive cards. Standard ease `cubic-bezier(0.2,0,0.1,1)`; emphasized ease for card lift. No bounces.
- **States:** hover = subtle lift + stronger shadow; press = slight scale-down; focus = 3px primary-tinted ring on inputs. Disabled = 0.45 opacity.
- **Transparency/blur:** avoid glassmorphism; surfaces are solid for legibility in sunlight.

## Iconography
- **Set:** [Lucide](https://lucide.dev) — clean 1.5–2px stroke, rounded joins; matches the calm/soft aesthetic. **Substitution flagged:** no icon assets were provided, so Lucide is used throughout (via `lucide-react` in the UI kit, `unpkg.com/lucide` in specimen cards). Swap for a brand set if one exists.
- Common glyphs: `search`, `map-pin`, `navigation`, `locate-fixed`, `bus`, `footprints`, `repeat` (transfer), `star`, `clock`, `thumbs-up`, `chevron-left`, `heart`.
- **Emoji:** only 👍 (Helpful). **Unicode:** `★` for star ratings, `›` as leg separators. No PNG icons.

---

## Index / manifest
- `styles.css` — global entry (import this); `@import`s all tokens + fonts.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `effects.css`, `fonts.css`.
- `guidelines/` — foundation specimen cards (Colors ×3, Type ×3, Spacing, Radius & Elevation).
- `components/core/` — **Button, IconButton, Input, Badge, Card** (+ `.d.ts`, `.prompt.md`, specimen card).
- `components/transit/` — **ModeBadge, CrowdMeter, RouteCard, ReviewCard** — the domain primitives that carry the review data.
- `ui_kits/lakbay-app/` — interactive `index.html` (Home → Results → Detail) + handoff screen JSX + README.
- `SKILL.md` — Agent-Skill wrapper.

### Intentional additions
Built from scratch (no source inventory), so components are the standard mobile set plus four domain primitives (`ModeBadge`, `CrowdMeter`, `RouteCard`, `ReviewCard`) required by the review-per-route concept.
